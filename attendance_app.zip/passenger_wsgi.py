import os
import sys

from attendance_project.wsgi import application