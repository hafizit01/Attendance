Install guide:
1. pip install -r requirements.txt
2. python manage.py migrate
3. python manage.py runserver
